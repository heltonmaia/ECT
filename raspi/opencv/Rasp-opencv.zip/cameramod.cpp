#include "opencv2/highgui/highgui.hpp"
#include <opencv2/imgproc/imgproc.hpp>
#include <time.h>
#include <stdio.h>
#include <sys/time.h>
#include <opencv2/core/core.hpp>
#include <iostream>
#include <fstream>
#include <opencv2/features2d/features2d.hpp>
#include "/home/lucas/Rasp-opencv-testes/funcoes.h"

using namespace std;
using namespace cv;


int main(int argc, char** argv)
{
  
    principal();


    return 0;
}
